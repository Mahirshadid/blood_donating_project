#ifndef RED1_H
#define RED1_H
#include "databasecon.h"
#include <QDebug>
#include <QSqlQuery>
#include <QMessageBox>
#include <QMainWindow>
#include "reg.h"
namespace Ui {
class Red1;
}

class Red1 : public QMainWindow
{
    Q_OBJECT

public:
    explicit Red1(QWidget *parent = nullptr);
    ~Red1();

private slots:
    void on_pushButton_clicked();


    void on_pushButton_3_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_4_clicked();

    void on_tableView_activated(const QModelIndex &index);

private:
    Ui::Red1 *ui;
    Reg reg;
};

#endif // RED1_H
