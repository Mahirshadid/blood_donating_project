#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QSqlQueryModel>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    databasecon conn;

    QSqlQueryModel *modal=new QSqlQueryModel();

    conn.Connect();

    QSqlQuery* qry=new QSqlQuery(conn.dataBase);

    qry->exec("select DonorID,Name,PhoneNo,Bloodgroup,Location,Available from dlist");
    qDebug() << "query exec";

    modal->setQuery(*qry);
    ui->tableView->setModel(modal);

    conn.Disconnect();
    qDebug() << (modal->rowCount());
}
