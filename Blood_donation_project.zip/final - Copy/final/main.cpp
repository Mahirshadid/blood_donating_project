#include "reddrop.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Reddrop w;
    w.show();

    return a.exec();
}
