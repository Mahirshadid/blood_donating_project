#include "reddrop.h"
#include "ui_reddrop.h"

Reddrop::Reddrop(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Reddrop)
{
    ui->setupUi(this);

}

Reddrop::~Reddrop()
{
    delete ui;
}

void Reddrop::on_pushButton_clicked()
{
    red1.show();
}

void Reddrop::on_pushButton_2_clicked()
{
    mainwindow.show();
}
