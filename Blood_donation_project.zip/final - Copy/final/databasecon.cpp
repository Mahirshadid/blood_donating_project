#include "databasecon.h"
#include <qdebug.h>
#include<QSqlDatabase>
databasecon::databasecon()
{
   dataBase= QSqlDatabase::addDatabase("QSQLITE");
   dataBase.setDatabaseName("C:/Users/mahir/OneDrive/Desktop/Qt/drop1.db");
}
bool databasecon::Connect()
{
    if(dataBase.open())
        return true;
    else {
        return false;
    }
}
void databasecon::Disconnect()
{
    dataBase.close();
}
