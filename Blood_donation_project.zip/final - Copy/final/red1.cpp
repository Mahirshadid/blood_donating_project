#include "red1.h"
#include "ui_red1.h"
#include <QSqlQueryModel>
#include <QModelIndex>

Red1::Red1(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Red1)
{
    ui->setupUi(this);
}

Red1::~Red1()
{
    delete ui;
}

void Red1::on_pushButton_clicked()
{
    QString phone,pass;

    phone=ui->lineEdit->text();
    pass=ui->lineEdit_2->text();

    databasecon conn;

    QSqlQueryModel *modal=new QSqlQueryModel();

      conn.Connect();
    if(conn.Connect())
    {
        qDebug()<<"Connected";
    }

    QSqlQuery* qry=new QSqlQuery(conn.dataBase);
    phone=ui->lineEdit->text();


   if(qry->exec("SELECT * FROM dlist WHERE PhoneNo= '"+phone+"' and Password= '"+pass+"'"))
       qDebug()<<"Query exec";
   {
       int c=0;
       while(qry->next()) c++;
       if(c>=1)
       {

           qry->exec("select DonorID,Name,Password,PhoneNo,Bloodgroup,Location,Available from dlist  WHERE PhoneNo='"+phone+"'");
           qDebug() << "query exec";


       }
       else {
           QMessageBox::information(this,"INFO","Login Failed");
       }
   }
   modal->setQuery(*qry);
   ui->tableView->setModel(modal);
   conn.Disconnect();
}



void Red1::on_pushButton_3_clicked()
{
    QString name,password,phone,bg,location,ldd;

    phone=ui->lineEdit->text();


    databasecon connection;

    if(connection.Connect())
    {
        qDebug()<<"Connected"<<endl;
    }

    QSqlQuery qry;
    if (qry.exec("DELETE FROM dlist WHERE PhoneNo='"+phone+"'"))
    {
        qDebug()<<"Query Exec"<<endl;
        QMessageBox::information(this,"INFO","Deleted");
    }


    connection.Disconnect();
}

void Red1::on_pushButton_2_clicked()
{
    QString name,password,phone,bg,location,available="No";
        QString DonorID=ui->l1_3->text();;
        name=ui->l1->text();
        password=ui->l2->text();
        phone=ui->l3->text();
        bg=ui->l4->text();
        location=ui->l5->text();

        databasecon connection;

        if(connection.Connect())
        {
            qDebug()<<"Connected"<<endl;
        }

        connection.Connect();
        if(ui->yesc->isChecked())
        {
            available= "Yes";
        }

        QSqlQuery qry;
        if (qry.exec("UPDATE dlist SET Name='"+name+"',Password='"+password+"',PhoneNo='"+phone+"',Bloodgroup='"+bg+"',Location='"+location+"',Available='"+available+"' WHERE DonorID='"+DonorID+"'"))
        {
            qDebug()<<"Query Exec"<<endl;
            QMessageBox::information(this,"INFO","Updated");
        }


        connection.Disconnect();
}

void Red1::on_pushButton_4_clicked()
{

    reg.show();
}

void Red1::on_tableView_activated(const QModelIndex &index)
{


   QString val=ui->tableView->model()->data(index).toString();

      /*DonorID=ui->l1_3->text();;
        name=ui->l1->text();
        password=ui->l2->text();
        phone=ui->l3->text();
        bg=ui->l4->text();
        location=ui->l5->text();*/

        databasecon connection;

        if(connection.Connect())
        {
            qDebug()<<"Connected"<<endl;
        }

connection.Connect();

        QSqlQuery qry;
        qry.prepare("Select * from dlist where DonorID='"+val+"'");

        if (qry.exec())
        {
            while(qry.next()) {
            ui->l1_3->setText(qry.value(0).toString());
            ui->l1->setText(qry.value(1).toString());
            ui->l2->setText(qry.value(2).toString());
            ui->l3->setText(qry.value(3).toString());
            ui->l4->setText(qry.value(4).toString());
            ui->l5->setText(qry.value(5).toString());
                              }
        }

qDebug()<<"Query Exec"<<endl;

        connection.Disconnect();
}
