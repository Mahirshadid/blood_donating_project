#ifndef DATABASECON_H
#define DATABASECON_H
#include<QSqlDatabase>

class databasecon
{
public:
    QSqlDatabase dataBase;
    databasecon();
    bool Connect();
    void Disconnect();
};

#endif // DATABASECON_H
