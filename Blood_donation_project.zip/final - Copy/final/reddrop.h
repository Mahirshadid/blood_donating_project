#ifndef REDDROP_H
#define REDDROP_H

#include <QMainWindow>
#include "red1.h"
#include "mainwindow.h"


namespace Ui {
class Reddrop;
}

class Reddrop : public QMainWindow
{
    Q_OBJECT

public:
    explicit Reddrop(QWidget *parent = nullptr);
    ~Reddrop();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::Reddrop *ui;
    Red1 red1;
    MainWindow mainwindow;

};

#endif // REDDROP_H
