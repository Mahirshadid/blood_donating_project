#ifndef REG_H
#define REG_H

#include <QMainWindow>
#include "databasecon.h"
#include <QDebug>
#include <QSqlQuery>
#include <QMessageBox>
#include "login.h"


namespace Ui {
class Reg;
}

class Reg : public QMainWindow
{
    Q_OBJECT

public:
    explicit Reg(QWidget *parent = nullptr);
    ~Reg();

private slots:
    void on_pushButton_2_clicked();

    void on_pushButton_clicked();

private:
    Ui::Reg *ui;
    Login login;

};

#endif // REG_H
