#include "reg.h"
#include "ui_reg.h"

Reg::Reg(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Reg)
{
    ui->setupUi(this);
}

Reg::~Reg()
{
    delete ui;
}

void Reg::on_pushButton_2_clicked()
{
    QString name,password,phone,bg,location;
    QString available= "No";
    QString unavailable= "No";

    name=ui->lineEdit_3->text();
    password=ui->lineEdit_4->text();
    phone=ui->lineEdit_8->text();
    bg=ui->lineEdit_5->text();
    location=ui->lineEdit_6->text();


    databasecon connection;

    if(connection.Connect())
    {
        qDebug()<<"Connected"<<endl;
    }

    if(ui->yesc->isChecked())
    {
        available= "Yes";
    }
    if(ui->noc->isChecked())
    {
        unavailable= "Yes";
    }
    QSqlQuery qry;
    if (qry.exec("INSERT INTO dlist (Name,Password,PhoneNo,Bloodgroup,Location,Available) VALUES ('"+name+"','"+password+"','"+phone+"','"+bg+"','"+location+"','"+available+"')"))
    {
        qDebug()<<"Query Exec"<<endl;
        QMessageBox::information(this,"INFO","Registration Success");
    }


    connection.Disconnect();
}

void Reg::on_pushButton_clicked()
{
   hide();
   login.show();
}
