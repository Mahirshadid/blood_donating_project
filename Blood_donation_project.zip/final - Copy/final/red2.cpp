#include "red2.h"
#include "ui_red2.h"
#include <QSqlQueryModel>
#include "databasecon.h"

Red2::Red2(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Red2)
{
    ui->setupUi(this);
}

Red2::~Red2()
{
    delete ui;
}

/*void Red2::on_pushButton_clicked()
{
  databasecon conn;

  QSqlQueryModel *modal=new QSqlQueryModel();

  conn.Connect();

  QSqlQuery* qry=new QSqlQuery(conn.dataBase);
  QString phone=ui->l1_2->text();
  qry->exec("select DonorID,Name,Password,PhoneNo,Bloodgroup,Location,Available from dlist  WHERE PhoneNo='"+phone+"'");
  qDebug() << "query exec";

  modal->setQuery(*qry);
  ui->tableView->setModel(modal);

  conn.Disconnect();
  qDebug() << (modal->rowCount());
}

void Red2::on_pushButton_2_clicked()
{  QString name,password,phone,bg,location,available="No";
    QString DonorID=ui->l1_3->text();;
    name=ui->l1->text();
    password=ui->l2->text();
    phone=ui->l3->text();
    bg=ui->l4->text();
    location=ui->l5->text();

    databasecon connection;

    if(connection.Connect())
    {
        qDebug()<<"Connected"<<endl;
    }


    if(ui->yesc->isChecked())
    {
        available= "Yes";
    }

    QSqlQuery qry;
    if (qry.exec("UPDATE dlist SET Name='"+name+"',Password='"+password+"',PhoneNo='"+phone+"',Bloodgroup='"+bg+"',Location='"+location+"',Available='"+available+"' WHERE DonorID='"+DonorID+"'"))
    {
        qDebug()<<"Query Exec"<<endl;
        QMessageBox::information(this,"INFO","Updated");
    }


    connection.Disconnect();
}

void Red2::on_pushButton_3_clicked()
{
    QString name,password,phone,bg,location,ldd;
  //  QString DonorID=ui->l1_3->text();;
  //  name=ui->l1->text();
  //  password=ui->l2->text();
    phone=ui->l1_2->text();
 //   bg=ui->l4->text();
 //   location=ui->l5->text();
//    ldd=ui->l6->text();

    databasecon connection;

    if(connection.Connect())
    {
        qDebug()<<"Connected"<<endl;
    }

    QSqlQuery qry;
    if (qry.exec("DELETE FROM dlist WHERE PhoneNo='"+phone+"'"))
    {
        qDebug()<<"Query Exec"<<endl;
        QMessageBox::information(this,"INFO","Deleted");
    }


    connection.Disconnect();
}
*/
