#ifndef RED2_H
#define RED2_H

#include <QMainWindow>
#include "databasecon.h"
#include <QDebug>
#include <QSqlQuery>
#include <QMessageBox>
namespace Ui {
class Red2;
}

class Red2 : public QMainWindow
{
    Q_OBJECT

public:
    explicit Red2(QWidget *parent = nullptr);
    ~Red2();

private slots:
  //  void on_pushButton_clicked();

   // void on_pushButton_2_clicked();

  //  void on_pushButton_3_clicked();

private:
    Ui::Red2 *ui;
};

#endif // RED2_H
