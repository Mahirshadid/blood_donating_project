/********************************************************************************
** Form generated from reading UI file 'red2.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RED2_H
#define UI_RED2_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTableView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Red2
{
public:
    QWidget *centralwidget;
    QPushButton *pushButton;
    QFrame *frame_3;
    QLineEdit *l1;
    QLineEdit *l4;
    QLineEdit *l5;
    QLineEdit *l6;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;
    QPushButton *pushButton_2;
    QLineEdit *l3;
    QLabel *label_11;
    QLineEdit *l2;
    QLabel *label_7;
    QLineEdit *l1_3;
    QLabel *label_13;
    QTableView *tableView;
    QFrame *frame;
    QLabel *label_12;
    QLineEdit *l1_2;
    QPushButton *pushButton_3;

    void setupUi(QMainWindow *Red2)
    {
        if (Red2->objectName().isEmpty())
            Red2->setObjectName(QString::fromUtf8("Red2"));
        Red2->resize(739, 502);
        Red2->setStyleSheet(QString::fromUtf8("*{\n"
"	background-image: url(:/new/prefix1/resource/20190909_162931.jpg);\n"
"font-family: century gothic;\n"
"font-size: 15px;\n"
"}\n"
"\n"
"QFrame{\n"
"background: #333;\n"
"border-radius: 24px;\n"
"}\n"
"\n"
"\n"
"QPushButton {\n"
"background: red;\n"
"border-radius: 15px;\n"
"}\n"
"\n"
"QLabel {\n"
"color: white;\n"
"}\n"
"\n"
"QPushButton:hover\n"
"{\n"
"color:white;\n"
"border-radius:15px;\n"
"background:#000000;\n"
"}"));
        centralwidget = new QWidget(Red2);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        pushButton = new QPushButton(centralwidget);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(110, 160, 171, 31));
        frame_3 = new QFrame(centralwidget);
        frame_3->setObjectName(QString::fromUtf8("frame_3"));
        frame_3->setGeometry(QRect(110, 220, 501, 271));
        frame_3->setStyleSheet(QString::fromUtf8(""));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Raised);
        l1 = new QLineEdit(frame_3);
        l1->setObjectName(QString::fromUtf8("l1"));
        l1->setGeometry(QRect(20, 120, 211, 20));
        l4 = new QLineEdit(frame_3);
        l4->setObjectName(QString::fromUtf8("l4"));
        l4->setGeometry(QRect(20, 170, 211, 20));
        l5 = new QLineEdit(frame_3);
        l5->setObjectName(QString::fromUtf8("l5"));
        l5->setGeometry(QRect(260, 180, 211, 20));
        l6 = new QLineEdit(frame_3);
        l6->setObjectName(QString::fromUtf8("l6"));
        l6->setGeometry(QRect(20, 220, 211, 20));
        label_5 = new QLabel(frame_3);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(200, 10, 131, 21));
        QFont font;
        font.setFamily(QString::fromUtf8("century gothic"));
        font.setBold(true);
        font.setWeight(75);
        label_5->setFont(font);
        label_6 = new QLabel(frame_3);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(20, 100, 91, 16));
        label_8 = new QLabel(frame_3);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(20, 150, 131, 16));
        label_9 = new QLabel(frame_3);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(260, 160, 101, 16));
        label_10 = new QLabel(frame_3);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(20, 200, 171, 16));
        pushButton_2 = new QPushButton(frame_3);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(280, 220, 161, 31));
        pushButton_2->setStyleSheet(QString::fromUtf8(""));
        l3 = new QLineEdit(frame_3);
        l3->setObjectName(QString::fromUtf8("l3"));
        l3->setGeometry(QRect(260, 130, 211, 20));
        label_11 = new QLabel(frame_3);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(260, 110, 121, 16));
        l2 = new QLineEdit(frame_3);
        l2->setObjectName(QString::fromUtf8("l2"));
        l2->setGeometry(QRect(260, 80, 211, 20));
        l2->setStyleSheet(QString::fromUtf8("border-color: rgb(255, 255, 255);"));
        label_7 = new QLabel(frame_3);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(260, 60, 101, 16));
        l1_3 = new QLineEdit(frame_3);
        l1_3->setObjectName(QString::fromUtf8("l1_3"));
        l1_3->setGeometry(QRect(20, 70, 211, 20));
        label_13 = new QLabel(frame_3);
        label_13->setObjectName(QString::fromUtf8("label_13"));
        label_13->setGeometry(QRect(20, 50, 91, 16));
        tableView = new QTableView(centralwidget);
        tableView->setObjectName(QString::fromUtf8("tableView"));
        tableView->setGeometry(QRect(40, 80, 651, 71));
        QFont font1;
        font1.setFamily(QString::fromUtf8("MS Shell Dlg 2"));
        font1.setPointSize(10);
        font1.setBold(false);
        font1.setItalic(false);
        font1.setWeight(9);
        tableView->setFont(font1);
        tableView->setStyleSheet(QString::fromUtf8("color: rgb(0, 0, 0);\n"
"background-color: rgb(255, 255, 255);\n"
"font: 75 10pt \"MS Shell Dlg 2\";"));
        frame = new QFrame(centralwidget);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(40, 10, 281, 61));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        label_12 = new QLabel(frame);
        label_12->setObjectName(QString::fromUtf8("label_12"));
        label_12->setGeometry(QRect(20, 10, 91, 16));
        l1_2 = new QLineEdit(frame);
        l1_2->setObjectName(QString::fromUtf8("l1_2"));
        l1_2->setGeometry(QRect(20, 30, 211, 20));
        l1_2->setStyleSheet(QString::fromUtf8("background-color: rgb(127, 123, 118);"));
        pushButton_3 = new QPushButton(centralwidget);
        pushButton_3->setObjectName(QString::fromUtf8("pushButton_3"));
        pushButton_3->setGeometry(QRect(430, 160, 171, 31));
        Red2->setCentralWidget(centralwidget);

        retranslateUi(Red2);

        QMetaObject::connectSlotsByName(Red2);
    } // setupUi

    void retranslateUi(QMainWindow *Red2)
    {
        Red2->setWindowTitle(QApplication::translate("Red2", "Edit Profile", nullptr));
        pushButton->setText(QApplication::translate("Red2", "Fetch Profile", nullptr));
        l6->setInputMask(QString());
        l6->setText(QApplication::translate("Red2", "ex: available/unavailable", nullptr));
        label_5->setText(QApplication::translate("Red2", "- Edit Profile -", nullptr));
        label_6->setText(QApplication::translate("Red2", "Name:", nullptr));
        label_8->setText(QApplication::translate("Red2", "Blood Group:", nullptr));
        label_9->setText(QApplication::translate("Red2", "Location:", nullptr));
        label_10->setText(QApplication::translate("Red2", "Avaibility:", nullptr));
        pushButton_2->setText(QApplication::translate("Red2", "Update", nullptr));
        label_11->setText(QApplication::translate("Red2", "Phone Number:", nullptr));
        label_7->setText(QApplication::translate("Red2", "Password:", nullptr));
        label_13->setText(QApplication::translate("Red2", "Donor ID:", nullptr));
        label_12->setText(QApplication::translate("Red2", "Phone No:", nullptr));
        pushButton_3->setText(QApplication::translate("Red2", "Delete Profile", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Red2: public Ui_Red2 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RED2_H
