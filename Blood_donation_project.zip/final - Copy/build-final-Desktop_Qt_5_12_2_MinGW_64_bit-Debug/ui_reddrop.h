/********************************************************************************
** Form generated from reading UI file 'reddrop.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REDDROP_H
#define UI_REDDROP_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Reddrop
{
public:
    QWidget *centralWidget;
    QFrame *frame;
    QPushButton *pushButton;
    QPushButton *pushButton_2;
    QLabel *label;
    QLabel *label_2;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout;
    QLabel *label_3;
    QLabel *label_4;

    void setupUi(QMainWindow *Reddrop)
    {
        if (Reddrop->objectName().isEmpty())
            Reddrop->setObjectName(QString::fromUtf8("Reddrop"));
        Reddrop->setWindowModality(Qt::NonModal);
        Reddrop->setEnabled(true);
        Reddrop->resize(739, 500);
        Reddrop->setStyleSheet(QString::fromUtf8("*{\n"
"	background-image: url(:/new/prefix1/resource/20190909_162931.jpg);\n"
"font-family: century gothic;\n"
"font-size: 15px;\n"
"}\n"
"\n"
"QFrame{\n"
"background: #333;\n"
"border-radius: 24px;\n"
"}\n"
"\n"
"\n"
"QPushButton {\n"
"background: red;\n"
"border-radius: 15px;\n"
"}\n"
"\n"
"QLabel {\n"
"color: white;\n"
"}\n"
"\n"
"QPushButton:hover\n"
"{\n"
"color:white;\n"
"border-radius:15px;\n"
"background:#000000;\n"
"}"));
        centralWidget = new QWidget(Reddrop);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        frame = new QFrame(centralWidget);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(170, 90, 391, 411));
        frame->setStyleSheet(QString::fromUtf8("border-color: rgb(255, 255, 255);\n"
"\n"
"\n"
"\n"
""));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        pushButton = new QPushButton(frame);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(30, 160, 341, 31));
        pushButton_2 = new QPushButton(frame);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(30, 200, 341, 31));
        label = new QLabel(frame);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(110, 70, 201, 61));
        QFont font;
        font.setFamily(QString::fromUtf8("century gothic"));
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        label_2 = new QLabel(frame);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(50, 110, 301, 21));
        layoutWidget = new QWidget(frame);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        layoutWidget->setGeometry(QRect(30, 380, 401, 16));
        horizontalLayout = new QHBoxLayout(layoutWidget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        QFont font1;
        font1.setFamily(QString::fromUtf8("Arial"));
        font1.setPointSize(8);
        font1.setBold(false);
        font1.setItalic(false);
        font1.setWeight(50);
        label_3->setFont(font1);
        label_3->setStyleSheet(QString::fromUtf8("font: 8pt \"Arial\";"));

        horizontalLayout->addWidget(label_3);

        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setStyleSheet(QString::fromUtf8("font: 8pt \"Arial\";"));

        horizontalLayout->addWidget(label_4);

        Reddrop->setCentralWidget(centralWidget);

        retranslateUi(Reddrop);

        QMetaObject::connectSlotsByName(Reddrop);
    } // setupUi

    void retranslateUi(QMainWindow *Reddrop)
    {
        Reddrop->setWindowTitle(QApplication::translate("Reddrop", "Reddrop", nullptr));
        pushButton->setText(QApplication::translate("Reddrop", "Donate", nullptr));
        pushButton_2->setText(QApplication::translate("Reddrop", "Find Donor", nullptr));
        label->setText(QApplication::translate("Reddrop", "             RedDrop", nullptr));
        label_2->setText(QApplication::translate("Reddrop", " - Your Blood companion in Chittagong -", nullptr));
        label_3->setText(QApplication::translate("Reddrop", "All Rights Reserved (R)", nullptr));
        label_4->setText(QApplication::translate("Reddrop", " Powered by BIT LEGION", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Reddrop: public Ui_Reddrop {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REDDROP_H
