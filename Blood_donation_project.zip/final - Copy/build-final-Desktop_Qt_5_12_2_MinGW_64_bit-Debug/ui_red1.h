/********************************************************************************
** Form generated from reading UI file 'red1.ui'
**
** Created by: Qt User Interface Compiler version 5.12.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_RED1_H
#define UI_RED1_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QFrame>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Red1
{
public:
    QWidget *centralwidget;
    QFrame *frame;
    QLabel *label;
    QLineEdit *lineEdit;
    QLineEdit *lineEdit_2;
    QLabel *label_3;
    QLabel *label_2;
    QPushButton *pushButton;
    QFrame *frame_2;
    QLabel *label_4;
    QFrame *frame_3;
    QLineEdit *lineEdit_3;
    QLineEdit *lineEdit_4;
    QLineEdit *lineEdit_5;
    QLineEdit *lineEdit_6;
    QLineEdit *lineEdit_7;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_10;
    QPushButton *pushButton_2;
    QLineEdit *lineEdit_8;
    QLabel *label_11;

    void setupUi(QMainWindow *Red1)
    {
        if (Red1->objectName().isEmpty())
            Red1->setObjectName(QString::fromUtf8("Red1"));
        Red1->resize(725, 500);
        Red1->setStyleSheet(QString::fromUtf8("*{\n"
"	background-image: url(:/new/prefix1/resource/20190909_162931.jpg);\n"
"font-family: century gothic;\n"
"font-size: 15px;\n"
"}\n"
"\n"
"QFrame{\n"
"background: #333;\n"
"border-radius: 24px;\n"
"}\n"
"\n"
"\n"
"QPushButton {\n"
"background: red;\n"
"border-radius: 15px;\n"
"}\n"
"\n"
"QLabel {\n"
"color: white;\n"
"}\n"
"\n"
"QPushButton:hover\n"
"{\n"
"color:white;\n"
"border-radius:15px;\n"
"background:#000000;\n"
"}"));
        centralwidget = new QWidget(Red1);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        frame = new QFrame(centralwidget);
        frame->setObjectName(QString::fromUtf8("frame"));
        frame->setGeometry(QRect(20, 100, 261, 271));
        frame->setFrameShape(QFrame::StyledPanel);
        frame->setFrameShadow(QFrame::Raised);
        label = new QLabel(frame);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(100, 10, 81, 21));
        QFont font;
        font.setFamily(QString::fromUtf8("century gothic"));
        font.setBold(true);
        font.setWeight(75);
        label->setFont(font);
        lineEdit = new QLineEdit(frame);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(20, 100, 221, 20));
        lineEdit_2 = new QLineEdit(frame);
        lineEdit_2->setObjectName(QString::fromUtf8("lineEdit_2"));
        lineEdit_2->setGeometry(QRect(20, 160, 221, 20));
        lineEdit_2->setEchoMode(QLineEdit::Password);
        label_3 = new QLabel(frame);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(20, 135, 91, 21));
        label_2 = new QLabel(frame);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(20, 70, 101, 21));
        pushButton = new QPushButton(frame);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));
        pushButton->setGeometry(QRect(20, 210, 221, 31));
        frame_2 = new QFrame(centralwidget);
        frame_2->setObjectName(QString::fromUtf8("frame_2"));
        frame_2->setGeometry(QRect(310, 220, 61, 51));
        frame_2->setFrameShape(QFrame::StyledPanel);
        frame_2->setFrameShadow(QFrame::Raised);
        label_4 = new QLabel(frame_2);
        label_4->setObjectName(QString::fromUtf8("label_4"));
        label_4->setGeometry(QRect(10, 10, 31, 31));
        frame_3 = new QFrame(centralwidget);
        frame_3->setObjectName(QString::fromUtf8("frame_3"));
        frame_3->setGeometry(QRect(390, 10, 311, 481));
        frame_3->setFrameShape(QFrame::StyledPanel);
        frame_3->setFrameShadow(QFrame::Raised);
        lineEdit_3 = new QLineEdit(frame_3);
        lineEdit_3->setObjectName(QString::fromUtf8("lineEdit_3"));
        lineEdit_3->setGeometry(QRect(20, 70, 271, 20));
        lineEdit_4 = new QLineEdit(frame_3);
        lineEdit_4->setObjectName(QString::fromUtf8("lineEdit_4"));
        lineEdit_4->setGeometry(QRect(20, 130, 271, 20));
        lineEdit_5 = new QLineEdit(frame_3);
        lineEdit_5->setObjectName(QString::fromUtf8("lineEdit_5"));
        lineEdit_5->setGeometry(QRect(20, 250, 271, 20));
        lineEdit_6 = new QLineEdit(frame_3);
        lineEdit_6->setObjectName(QString::fromUtf8("lineEdit_6"));
        lineEdit_6->setGeometry(QRect(20, 310, 271, 20));
        lineEdit_7 = new QLineEdit(frame_3);
        lineEdit_7->setObjectName(QString::fromUtf8("lineEdit_7"));
        lineEdit_7->setGeometry(QRect(20, 370, 271, 20));
        label_5 = new QLabel(frame_3);
        label_5->setObjectName(QString::fromUtf8("label_5"));
        label_5->setGeometry(QRect(100, 10, 131, 21));
        label_5->setFont(font);
        label_6 = new QLabel(frame_3);
        label_6->setObjectName(QString::fromUtf8("label_6"));
        label_6->setGeometry(QRect(20, 50, 91, 16));
        label_7 = new QLabel(frame_3);
        label_7->setObjectName(QString::fromUtf8("label_7"));
        label_7->setGeometry(QRect(20, 110, 101, 16));
        label_8 = new QLabel(frame_3);
        label_8->setObjectName(QString::fromUtf8("label_8"));
        label_8->setGeometry(QRect(20, 230, 131, 16));
        label_9 = new QLabel(frame_3);
        label_9->setObjectName(QString::fromUtf8("label_9"));
        label_9->setGeometry(QRect(20, 290, 101, 16));
        label_10 = new QLabel(frame_3);
        label_10->setObjectName(QString::fromUtf8("label_10"));
        label_10->setGeometry(QRect(20, 350, 171, 16));
        pushButton_2 = new QPushButton(frame_3);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setGeometry(QRect(20, 410, 271, 31));
        lineEdit_8 = new QLineEdit(frame_3);
        lineEdit_8->setObjectName(QString::fromUtf8("lineEdit_8"));
        lineEdit_8->setGeometry(QRect(20, 190, 271, 20));
        label_11 = new QLabel(frame_3);
        label_11->setObjectName(QString::fromUtf8("label_11"));
        label_11->setGeometry(QRect(20, 170, 121, 16));
        Red1->setCentralWidget(centralwidget);

        retranslateUi(Red1);

        QMetaObject::connectSlotsByName(Red1);
    } // setupUi

    void retranslateUi(QMainWindow *Red1)
    {
        Red1->setWindowTitle(QApplication::translate("Red1", "Donate", nullptr));
        label->setText(QApplication::translate("Red1", "- Login -", nullptr));
        label_3->setText(QApplication::translate("Red1", "Password:", nullptr));
        label_2->setText(QApplication::translate("Red1", "Phone No:", nullptr));
        pushButton->setText(QApplication::translate("Red1", "Login", nullptr));
        label_4->setText(QApplication::translate("Red1", "   Or", nullptr));
        lineEdit_7->setInputMask(QString());
        lineEdit_7->setText(QApplication::translate("Red1", "ex: available/unavailable", nullptr));
        label_5->setText(QApplication::translate("Red1", "- Registration -", nullptr));
        label_6->setText(QApplication::translate("Red1", "Name:", nullptr));
        label_7->setText(QApplication::translate("Red1", "Password:", nullptr));
        label_8->setText(QApplication::translate("Red1", "Blood Group:", nullptr));
        label_9->setText(QApplication::translate("Red1", "Location:", nullptr));
        label_10->setText(QApplication::translate("Red1", "Avaibility:", nullptr));
        pushButton_2->setText(QApplication::translate("Red1", "Register", nullptr));
        label_11->setText(QApplication::translate("Red1", "Phone Number:", nullptr));
    } // retranslateUi

};

namespace Ui {
    class Red1: public Ui_Red1 {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_RED1_H
